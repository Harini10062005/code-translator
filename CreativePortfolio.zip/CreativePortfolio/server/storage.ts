import { Translation, Workspace, InsertTranslation, InsertWorkspace } from "../shared/schema";
import { nanoid } from "nanoid";

export interface IStorage {
  // Translations
  createTranslation(data: InsertTranslation): Promise<Translation>;
  getTranslationsByWorkspace(workspaceId: string): Promise<Translation[]>;
  getRecentTranslations(limit?: number): Promise<Translation[]>;
  
  // Workspaces
  createWorkspace(data: InsertWorkspace): Promise<Workspace>;
  getWorkspaces(): Promise<Workspace[]>;
  getWorkspaceById(id: string): Promise<Workspace | null>;
  updateWorkspace(id: string, data: Partial<InsertWorkspace>): Promise<Workspace | null>;
  deleteWorkspace(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private translations: Translation[] = [];
  private workspaces: Workspace[] = [];

  constructor() {
    // Create default workspace
    this.workspaces.push({
      id: "main-project",
      name: "Main Project",
      isActive: true,
      createdAt: new Date(),
    });
  }

  async createTranslation(data: InsertTranslation): Promise<Translation> {
    const translation: Translation = {
      ...data,
      id: nanoid(),
      createdAt: new Date(),
    };
    
    this.translations.unshift(translation);
    return translation;
  }

  async getTranslationsByWorkspace(workspaceId: string): Promise<Translation[]> {
    return this.translations.filter(t => t.workspaceId === workspaceId);
  }

  async getRecentTranslations(limit = 10): Promise<Translation[]> {
    return this.translations
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createWorkspace(data: InsertWorkspace): Promise<Workspace> {
    const workspace: Workspace = {
      ...data,
      id: nanoid(),
      createdAt: new Date(),
    };
    
    this.workspaces.push(workspace);
    return workspace;
  }

  async getWorkspaces(): Promise<Workspace[]> {
    return this.workspaces.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getWorkspaceById(id: string): Promise<Workspace | null> {
    return this.workspaces.find(w => w.id === id) || null;
  }

  async updateWorkspace(id: string, data: Partial<InsertWorkspace>): Promise<Workspace | null> {
    const index = this.workspaces.findIndex(w => w.id === id);
    if (index === -1) return null;
    
    this.workspaces[index] = { ...this.workspaces[index], ...data };
    return this.workspaces[index];
  }

  async deleteWorkspace(id: string): Promise<boolean> {
    const index = this.workspaces.findIndex(w => w.id === id);
    if (index === -1) return false;
    
    this.workspaces.splice(index, 1);
    // Also remove translations from this workspace
    this.translations = this.translations.filter(t => t.workspaceId !== id);
    return true;
  }
}

export const storage = new MemStorage();
