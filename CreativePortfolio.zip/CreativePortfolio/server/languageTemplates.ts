// Language-specific templates and patterns for code translation
export interface LanguageTemplate {
  name: string;
  extension: string;
  printStatement: (text: string) => string;
  variableDeclaration: (name: string, value: string, type?: string) => string;
  functionDeclaration: (name: string, params: string[], body: string, returnType?: string) => string;
  comment: (text: string) => string;
  imports: string[];
  mainFunction?: (body: string) => string;
}

export const languageTemplates: Record<string, LanguageTemplate> = {
  javascript: {
    name: "JavaScript",
    extension: ".js",
    printStatement: (text) => `console.log(${text});`,
    variableDeclaration: (name, value) => `let ${name} = ${value};`,
    functionDeclaration: (name, params, body) => `function ${name}(${params.join(', ')}) {\n${body}\n}`,
    comment: (text) => `// ${text}`,
    imports: []
  },
  
  python: {
    name: "Python",
    extension: ".py",
    printStatement: (text) => `print(${text})`,
    variableDeclaration: (name, value) => `${name} = ${value}`,
    functionDeclaration: (name, params, body) => `def ${name}(${params.join(', ')}):\n    ${body.split('\n').join('\n    ')}`,
    comment: (text) => `# ${text}`,
    imports: []
  },
  
  java: {
    name: "Java",
    extension: ".java",
    printStatement: (text) => `System.out.println(${text});`,
    variableDeclaration: (name, value, type = "String") => `${type} ${name} = ${value};`,
    functionDeclaration: (name, params, body, returnType = "void") => `public static ${returnType} ${name}(${params.join(', ')}) {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: [],
    mainFunction: (body) => `public class Main {
    public static void main(String[] args) {
        ${body.split('\n').join('\n        ')}
    }
}`
  },
  
  cpp: {
    name: "C++",
    extension: ".cpp",
    printStatement: (text) => `std::cout << ${text} << std::endl;`,
    variableDeclaration: (name, value, type = "auto") => `${type} ${name} = ${value};`,
    functionDeclaration: (name, params, body, returnType = "void") => `${returnType} ${name}(${params.join(', ')}) {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: ["#include <iostream>", "#include <string>"],
    mainFunction: (body) => `int main() {
    ${body.split('\n').join('\n    ')}
    return 0;
}`
  },
  
  c: {
    name: "C",
    extension: ".c",
    printStatement: (text) => `printf(${text});`,
    variableDeclaration: (name, value, type = "char*") => `${type} ${name} = ${value};`,
    functionDeclaration: (name, params, body, returnType = "void") => `${returnType} ${name}(${params.join(', ')}) {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: ["#include <stdio.h>", "#include <string.h>"],
    mainFunction: (body) => `int main() {
    ${body.split('\n').join('\n    ')}
    return 0;
}`
  },
  
  csharp: {
    name: "C#",
    extension: ".cs",
    printStatement: (text) => `Console.WriteLine(${text});`,
    variableDeclaration: (name, value, type = "string") => `${type} ${name} = ${value};`,
    functionDeclaration: (name, params, body, returnType = "void") => `public static ${returnType} ${name}(${params.join(', ')}) {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: ["using System;"],
    mainFunction: (body) => `class Program {
    static void Main() {
        ${body.split('\n').join('\n        ')}
    }
}`
  },
  
  go: {
    name: "Go",
    extension: ".go",
    printStatement: (text) => `fmt.Println(${text})`,
    variableDeclaration: (name, value) => `${name} := ${value}`,
    functionDeclaration: (name, params, body, returnType = "") => `func ${name}(${params.join(', ')}) ${returnType} {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: ["package main", "import \"fmt\""],
    mainFunction: (body) => `func main() {
    ${body.split('\n').join('\n    ')}
}`
  },
  
  rust: {
    name: "Rust",
    extension: ".rs",
    printStatement: (text) => `println!("{}", ${text});`,
    variableDeclaration: (name, value) => `let ${name} = ${value};`,
    functionDeclaration: (name, params, body, returnType = "()") => `fn ${name}(${params.join(', ')}) -> ${returnType} {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: [],
    mainFunction: (body) => `fn main() {
    ${body.split('\n').join('\n    ')}
}`
  },
  
  php: {
    name: "PHP",
    extension: ".php",
    printStatement: (text) => `echo ${text};`,
    variableDeclaration: (name, value) => `$${name} = ${value};`,
    functionDeclaration: (name, params, body) => `function ${name}(${params.join(', ')}) {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: ["<?php"]
  },
  
  swift: {
    name: "Swift",
    extension: ".swift",
    printStatement: (text) => `print(${text})`,
    variableDeclaration: (name, value) => `let ${name} = ${value}`,
    functionDeclaration: (name, params, body, returnType = "Void") => `func ${name}(${params.join(', ')}) -> ${returnType} {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: []
  },
  
  kotlin: {
    name: "Kotlin",
    extension: ".kt",
    printStatement: (text) => `println(${text})`,
    variableDeclaration: (name, value) => `val ${name} = ${value}`,
    functionDeclaration: (name, params, body, returnType = "Unit") => `fun ${name}(${params.join(', ')}): ${returnType} {\n    ${body.split('\n').join('\n    ')}\n}`,
    comment: (text) => `// ${text}`,
    imports: [],
    mainFunction: (body) => `fun main() {
    ${body.split('\n').join('\n    ')}
}`
  }
};

// Demo examples for each language
export const demoExamples = {
  helloWorld: {
    description: "Simple Hello World program",
    examples: {
      javascript: `console.log("Hello, World!");`,
      python: `print("Hello, World!")`,
      java: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}`,
      cpp: `#include <iostream>
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}`,
      c: `#include <stdio.h>
int main() {
    printf("Hello, World!\\n");
    return 0;
}`,
      csharp: `using System;
class Program {
    static void Main() {
        Console.WriteLine("Hello, World!");
    }
}`,
      go: `package main
import "fmt"
func main() {
    fmt.Println("Hello, World!")
}`,
      rust: `fn main() {
    println!("Hello, World!");
}`,
      php: `<?php
echo "Hello, World!";
?>`,
      swift: `print("Hello, World!")`,
      kotlin: `fun main() {
    println("Hello, World!")
}`
    }
  },
  
  variables: {
    description: "Variable declaration and usage",
    examples: {
      javascript: `let name = "John";
let age = 25;
console.log("Name: " + name + ", Age: " + age);`,
      python: `name = "John"
age = 25
print(f"Name: {name}, Age: {age}")`,
      java: `public class Main {
    public static void main(String[] args) {
        String name = "John";
        int age = 25;
        System.out.println("Name: " + name + ", Age: " + age);
    }
}`,
      cpp: `#include <iostream>
#include <string>
int main() {
    std::string name = "John";
    int age = 25;
    std::cout << "Name: " << name << ", Age: " << age << std::endl;
    return 0;
}`,
      c: `#include <stdio.h>
int main() {
    char name[] = "John";
    int age = 25;
    printf("Name: %s, Age: %d\\n", name, age);
    return 0;
}`
    }
  }
};