import { Router } from "express";
import { storage } from "./storage";
import { translateCodeSchema, formatCodeSchema } from "../shared/schema";
import { log } from "./vite";
import { fallbackTranslate } from "./fallbackTranslator";
import { languageTemplates, demoExamples } from "./languageTemplates";

const router = Router();

// Helper function to get error message
function getErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Unknown error";
}

// Rule-based code translator - no AI dependencies

// Get all workspaces
router.get("/api/workspaces", async (req, res) => {
  try {
    const workspaces = await storage.getWorkspaces();
    res.json(workspaces);
  } catch (error) {
    log(`Error fetching workspaces: ${getErrorMessage(error)}`, "api");
    res.status(500).json({ error: "Failed to fetch workspaces" });
  }
});

// Create workspace
router.post("/api/workspaces", async (req, res) => {
  try {
    const workspace = await storage.createWorkspace(req.body);
    res.json(workspace);
  } catch (error) {
    log(`Error creating workspace: ${getErrorMessage(error)}`, "api");
    res.status(500).json({ error: "Failed to create workspace" });
  }
});

// Get recent translations
router.get("/api/translations/recent", async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const translations = await storage.getRecentTranslations(limit);
    res.json(translations);
  } catch (error) {
    log(`Error fetching recent translations: ${getErrorMessage(error)}`, "api");
    res.status(500).json({ error: "Failed to fetch translations" });
  }
});

// Get supported languages
router.get("/api/languages", (req, res) => {
  const languages = Object.keys(languageTemplates).map(key => ({
    id: key,
    name: languageTemplates[key].name,
    extension: languageTemplates[key].extension
  }));
  res.json(languages);
});

// Get demo examples
router.get("/api/demo/:type", (req, res) => {
  const { type } = req.params;
  const demo = demoExamples[type as keyof typeof demoExamples];
  
  if (!demo) {
    return res.status(404).json({ error: "Demo type not found" });
  }
  
  res.json(demo);
});

// Get all demo types
router.get("/api/demos", (req, res) => {
  const demos = Object.keys(demoExamples).map(key => ({
    type: key,
    description: demoExamples[key as keyof typeof demoExamples].description
  }));
  res.json(demos);
});

// Quick translation demo endpoint
router.post("/api/translate/demo", (req, res) => {
  const { sourceLanguage, targetLanguage, demoType } = req.body;
  
  if (!sourceLanguage || !targetLanguage || !demoType) {
    return res.status(400).json({ error: "Missing required parameters" });
  }

  const demo = demoExamples[demoType as keyof typeof demoExamples];
  if (!demo) {
    return res.status(404).json({ error: "Demo type not found" });
  }

  const sourceCode = demo.examples[sourceLanguage as keyof typeof demo.examples];
  if (!sourceCode) {
    return res.status(404).json({ error: "Source language example not found" });
  }

  // Use fallback translator for demo
  const mockSourceLanguage = { id: sourceLanguage, name: sourceLanguage };
  const mockTargetLanguage = { id: targetLanguage, name: targetLanguage };
  
  const result = fallbackTranslate(sourceCode, mockSourceLanguage as any, mockTargetLanguage as any);
  
  res.json({
    sourceCode,
    translatedCode: result.translatedCode,
    confidence: result.confidence,
    sourceLanguage: mockSourceLanguage,
    targetLanguage: mockTargetLanguage,
    demoType
  });
});

// Get translations by workspace
router.get("/api/translations/workspace/:workspaceId", async (req, res) => {
  try {
    const translations = await storage.getTranslationsByWorkspace(
      req.params.workspaceId,
    );
    res.json(translations);
  } catch (error) {
    log(
      `Error fetching workspace translations: ${getErrorMessage(error)}`,
      "api",
    );
    res.status(500).json({ error: "Failed to fetch workspace translations" });
  }
});

// Translate code
router.post("/api/translate", async (req, res) => {
  try {
    const validatedData = translateCodeSchema.parse(req.body);
    const { sourceCode, sourceLanguage, targetLanguage, workspaceId } =
      validatedData;

    log(
      `Translating from ${sourceLanguage.name} to ${targetLanguage.name}`,
      "translation",
    );

    const startTime = Date.now();

    // Use rule-based translation only (no AI)
    log("Using rule-based translator", "translation");
    
    const result = fallbackTranslate(
      sourceCode,
      sourceLanguage,
      targetLanguage,
    );
    
    const processingTime = Date.now() - startTime;

    // Store the translation
    const translation = await storage.createTranslation({
      workspaceId,
      sourceLanguage,
      targetLanguage,
      sourceCode,
      translatedCode: result.translatedCode,
      confidence: result.confidence,
      processingTime,
    });

    log(
      `Rule-based translation completed in ${processingTime}ms with ${translation.confidence}% confidence`,
      "translation",
    );

    res.json({
      ...translation,
      method: "rule-based",
      message: "Translated using pattern-matching rules"
    });
  } catch (error) {
    const errorMessage = getErrorMessage(error);
    log(`Translation error: ${errorMessage}`, "translation");

    // No API key errors for rule-based translation

    res.status(500).json({
      error: "Translation failed",
      details: errorMessage,
      type: "general_error",
    });
  }
});

// Format code (Rule-based, no AI)
router.post("/api/format", async (req, res) => {
  try {
    const validatedData = formatCodeSchema.parse(req.body);
    const { code, language } = validatedData;

    // Simple rule-based formatting
    let formattedCode = code;
    
    // Basic formatting rules for different languages
    if (language.id === "javascript" || language.id === "typescript") {
      formattedCode = formatJavaScript(code);
    } else if (language.id === "python") {
      formattedCode = formatPython(code);
    } else if (language.id === "java") {
      formattedCode = formatJava(code);
    } else {
      // Generic formatting
      formattedCode = formatGeneric(code);
    }

    res.json({ 
      formattedCode,
      method: "rule-based",
      message: "Formatted using basic rules"
    });
  } catch (error) {
    const errorMessage = getErrorMessage(error);
    log(`Formatting error: ${errorMessage}`, "format");

    res.status(500).json({
      error: "Code formatting failed",
      details: errorMessage,
      type: "general_error",
    });
  }
});

// Simple formatting functions
function formatJavaScript(code: string): string {
  return code
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => {
      if (line.includes('{') && !line.includes('}')) return line;
      if (line.includes('}')) return line;
      if (line.startsWith('if') || line.startsWith('for') || line.startsWith('while')) return line;
      return line.endsWith(';') ? line : line + ';';
    })
    .join('\n');
}

function formatPython(code: string): string {
  return code
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .join('\n');
}

function formatJava(code: string): string {
  return code
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => line.endsWith(';') || line.endsWith('{') || line.endsWith('}') ? line : line + ';')
    .join('\n');
}

function formatGeneric(code: string): string {
  return code
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .join('\n');
}

export default router;
