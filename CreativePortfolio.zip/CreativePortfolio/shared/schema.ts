import { z } from "zod";

// Language schema
export const languageSchema = z.object({
  id: z.string(),
  name: z.string(),
  short: z.string(),
  fileExtension: z.string(),
  monacoLanguage: z.string(),
});

export type Language = z.infer<typeof languageSchema>;

// Translation schema
export const translationSchema = z.object({
  id: z.string(),
  workspaceId: z.string(),
  sourceLanguage: languageSchema,
  targetLanguage: languageSchema,
  sourceCode: z.string(),
  translatedCode: z.string(),
  confidence: z.number().min(0).max(100),
  processingTime: z.number(),
  createdAt: z.date(),
  isFallback: z.boolean().optional(),
  fallbackMessage: z.string().optional(),
});

export const insertTranslationSchema = translationSchema.omit({
  id: true,
  createdAt: true,
});

export type Translation = z.infer<typeof translationSchema>;
export type InsertTranslation = z.infer<typeof insertTranslationSchema>;

// Workspace schema
export const workspaceSchema = z.object({
  id: z.string(),
  name: z.string(),
  isActive: z.boolean(),
  createdAt: z.date(),
});

export const insertWorkspaceSchema = workspaceSchema.omit({
  id: true,
  createdAt: true,
});

export type Workspace = z.infer<typeof workspaceSchema>;
export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;

// API request schemas
export const translateCodeSchema = z.object({
  sourceCode: z.string().min(1, "Source code is required"),
  sourceLanguage: languageSchema,
  targetLanguage: languageSchema,
  workspaceId: z.string(),
});

export type TranslateCodeRequest = z.infer<typeof translateCodeSchema>;

export const formatCodeSchema = z.object({
  code: z.string(),
  language: languageSchema,
});

export type FormatCodeRequest = z.infer<typeof formatCodeSchema>;
