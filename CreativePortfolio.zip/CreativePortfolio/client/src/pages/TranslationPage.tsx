import { useState, useCallback } from "react";
import { Copy, FileText, Download } from "lucide-react";
import { Language } from "@shared/schema";
import { supportedLanguages } from "@/lib/languages";
import { useTranslation } from "@/hooks/useTranslation";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { formatCode, getCodeStats } from "@/lib/codeFormatter";
import { useTheme } from "@/components/ThemeProvider";
import { SimpleCodeEditor } from "@/components/SimpleCodeEditor";
import { EditorToolbar } from "@/components/EditorToolbar";
import { StatusBar } from "@/components/StatusBar";
import { KeyboardShortcutsModal } from "@/components/KeyboardShortcutsModal";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface TranslationPageProps {
  activeWorkspaceId: string;
}

export function TranslationPage({ activeWorkspaceId }: TranslationPageProps) {
  const { toast } = useToast();
  const { toggleTheme } = useTheme();
  const { translateCode, isTranslating } = useTranslation();

  const [sourceLanguage, setSourceLanguage] = useState<Language>(
    supportedLanguages.find(l => l.id === "python") || supportedLanguages[0]
  );
  const [targetLanguage, setTargetLanguage] = useState<Language>(
    supportedLanguages.find(l => l.id === "javascript") || supportedLanguages[1]
  );
  const [sourceCode, setSourceCode] = useState("");
  const [translatedCode, setTranslatedCode] = useState("");
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [lastTranslation, setLastTranslation] = useState<any>(null);

  const handleTranslate = useCallback(async () => {
    if (!sourceCode.trim()) {
      toast({
        title: "Source code required",
        description: "Please enter some code to translate.",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await translateCode.mutateAsync({
        sourceCode,
        sourceLanguage,
        targetLanguage,
        workspaceId: activeWorkspaceId,
      });

      setTranslatedCode(result.translatedCode);
      setLastTranslation(result);
      
      // Check if this is a fallback translation
      if (result.isFallback) {
        toast({
          title: "Basic translation completed",
          description: `Code converted with ${result.confidence}% confidence using fallback translator. Add OpenAI credits for better results.`,
          variant: "default",
        });
      } else {
        toast({
          title: "Translation completed",
          description: `Code translated with ${result.confidence}% confidence`,
        });
      }
    } catch (error: any) {
      let title = "Translation failed";
      let description = error.message || "An error occurred during translation";
      
      // Handle specific error types from our improved backend
      if (error.response?.data?.type === "quota_exceeded") {
        title = "OpenAI Quota Exceeded";
        description = "Your OpenAI account has reached its usage limit. Please add credits or wait for reset.";
      } else if (error.response?.data?.type === "invalid_key") {
        title = "API Key Issue";
        description = "The OpenAI API key needs to be updated. Please check your configuration.";
      } else if (error.response?.status === 429) {
        title = "OpenAI Quota Exceeded";
        description = "Your OpenAI account has reached its usage limit. Please add credits at platform.openai.com/account/billing";
      }
      
      toast({
        title,
        description,
        variant: "destructive",
      });
    }
  }, [sourceCode, sourceLanguage, targetLanguage, activeWorkspaceId, translateCode, toast]);

  const handleFormat = useCallback(async () => {
    if (!sourceCode.trim()) return;

    try {
      const formatted = await formatCode(sourceCode, sourceLanguage);
      setSourceCode(formatted);
      toast({
        title: "Code formatted",
        description: "Your code has been formatted successfully",
      });
    } catch (error) {
      toast({
        title: "Formatting failed",
        description: "Unable to format the code",
        variant: "destructive",
      });
    }
  }, [sourceCode, sourceLanguage, toast]);

  const handleClear = useCallback(() => {
    setSourceCode("");
    setTranslatedCode("");
    setLastTranslation(null);
    toast({
      title: "Editors cleared",
      description: "Both source and translated code have been cleared",
    });
  }, [toast]);

  const handleCopyTranslated = useCallback(async () => {
    if (!translatedCode) {
      toast({
        title: "Nothing to copy",
        description: "No translated code available",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(translatedCode);
      toast({
        title: "Code copied",
        description: "Translated code copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy code to clipboard",
        variant: "destructive",
      });
    }
  }, [translatedCode, toast]);

  const handleSwapLanguages = useCallback(() => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setSourceCode(translatedCode);
    setTranslatedCode("");
    setLastTranslation(null);
  }, [sourceLanguage, targetLanguage, translatedCode]);

  const handleExportCode = useCallback(() => {
    if (!translatedCode) {
      toast({
        title: "Nothing to export",
        description: "No translated code available",
        variant: "destructive",
      });
      return;
    }

    const blob = new Blob([translatedCode], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `translated_code${targetLanguage.fileExtension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Code exported",
      description: "Translated code has been downloaded",
    });
  }, [translatedCode, targetLanguage, toast]);

  const handleImportFile = useCallback(() => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".py,.js,.ts,.java,.cpp,.cs,.go,.rs,.php,.rb,.swift,.kt";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          setSourceCode(content);
          
          // Try to detect language from file extension
          const extension = "." + file.name.split(".").pop();
          const detectedLanguage = supportedLanguages.find(
            lang => lang.fileExtension === extension
          );
          if (detectedLanguage) {
            setSourceLanguage(detectedLanguage);
          }

          toast({
            title: "File imported",
            description: `${file.name} has been loaded into the editor`,
          });
        };
        reader.readAsText(file);
      }
    };
    input.click();
  }, [toast]);

  useKeyboardShortcuts({
    onTranslate: handleTranslate,
    onFormat: handleFormat,
    onClear: handleClear,
    onCopy: handleCopyTranslated,
    onToggleTheme: toggleTheme,
  });

  const sourceStats = getCodeStats(sourceCode);
  const translatedStats = getCodeStats(translatedCode);

  return (
    <main className="flex-1 flex flex-col bg-gradient-to-br from-slate-50 via-blue-50/30 to-purple-50/30 dark:from-slate-900 dark:via-blue-950/30 dark:to-purple-950/30">
      <EditorToolbar
        sourceLanguage={sourceLanguage}
        targetLanguage={targetLanguage}
        onSourceLanguageChange={setSourceLanguage}
        onTargetLanguageChange={setTargetLanguage}
        onSwapLanguages={handleSwapLanguages}
        onFormat={handleFormat}
        onClear={handleClear}
        onTranslate={handleTranslate}
        isTranslating={isTranslating}
      />

      {/* Enhanced Code Editors */}
      <div className="flex-1 flex gap-1 p-1">
        {/* Source Editor */}
        <div className="flex-1 flex flex-col bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg animate-fade-in">
          <div className="bg-gradient-to-r from-white via-orange-50/50 to-yellow-50/50 dark:from-slate-800 dark:via-orange-900/20 dark:to-yellow-900/20 border-b border-slate-200/50 dark:border-slate-700/50 px-6 py-4 rounded-t-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-orange-400 rounded-full animate-pulse-soft"></div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 tracking-wide">
                    Source Code
                  </h3>
                </div>
                <span className="text-xs px-3 py-1.5 bg-gradient-to-r from-orange-100 to-yellow-100 dark:from-orange-900/40 dark:to-yellow-900/40 text-orange-700 dark:text-orange-300 rounded-lg font-semibold border border-orange-200 dark:border-orange-800">
                  {sourceLanguage.short}
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleImportFile}
                  className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 transition-all duration-200 hover:scale-105"
                >
                  <FileText className="w-3 h-3 mr-1.5" />
                  Import
                </Button>
                <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded-lg">
                    {sourceStats.lines} lines
                  </span>
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded-lg">
                    {sourceStats.chars} chars
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 p-2">
            <SimpleCodeEditor
              value={sourceCode}
              onChange={setSourceCode}
              language={sourceLanguage}
              placeholder="// Enter your source code here..."
              className="rounded-lg overflow-hidden code-block"
            />
          </div>
        </div>

        {/* Target Editor */}
        <div className="flex-1 flex flex-col bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-xl border border-slate-200/50 dark:border-slate-700/50 shadow-lg animate-fade-in" style={{ animationDelay: "0.2s" }}>
          <div className="bg-gradient-to-r from-white via-emerald-50/50 to-green-50/50 dark:from-slate-800 dark:via-emerald-900/20 dark:to-green-900/20 border-b border-slate-200/50 dark:border-slate-700/50 px-6 py-4 rounded-t-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse-soft"></div>
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 tracking-wide">
                    Translated Code
                  </h3>
                </div>
                <span className="text-xs px-3 py-1.5 bg-gradient-to-r from-emerald-100 to-green-100 dark:from-emerald-900/40 dark:to-green-900/40 text-emerald-700 dark:text-emerald-300 rounded-lg font-semibold border border-emerald-200 dark:border-emerald-800">
                  {targetLanguage.short}
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleCopyTranslated}
                  disabled={!translatedCode}
                  className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-all duration-200 hover:scale-105 disabled:opacity-50"
                >
                  <Copy className="w-3 h-3 mr-1.5" />
                  Copy
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleExportCode}
                  disabled={!translatedCode}
                  className="text-xs px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-all duration-200 hover:scale-105 disabled:opacity-50"
                >
                  <Download className="w-3 h-3 mr-1.5" />
                  Export
                </Button>
                <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded-lg">
                    {translatedStats.lines} lines
                  </span>
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded-lg">
                    {translatedStats.chars} chars
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 p-2">
            {isTranslating ? (
              <div className="flex-1 flex items-center justify-center h-full bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-blue-950 rounded-lg border border-slate-200/50 dark:border-slate-700/50">
                <div className="text-center p-8">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 border-4 border-blue-200 dark:border-blue-800 border-t-blue-600 dark:border-t-blue-400 rounded-full animate-spin mx-auto" />
                    <div className="absolute inset-0 w-16 h-16 border-4 border-transparent border-r-purple-400 rounded-full animate-spin mx-auto" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
                  </div>
                  <h4 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2">
                    Translating your code...
                  </h4>
                  <p className="text-slate-600 dark:text-slate-400 text-sm mb-3">
                    AI is analyzing and converting syntax
                  </p>
                  <div className="flex items-center justify-center space-x-2 text-xs text-slate-500 dark:text-slate-400">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                    <span>Processing with GPT-4</span>
                  </div>
                </div>
              </div>
            ) : (
              <SimpleCodeEditor
                value={translatedCode}
                onChange={setTranslatedCode}
                language={targetLanguage}
                placeholder="// Translated code will appear here..."
                readOnly
                className="rounded-lg overflow-hidden code-block"
              />
            )}
          </div>
        </div>
      </div>

      <StatusBar
        sourceStats={sourceStats}
        translatedStats={translatedStats}
        confidence={lastTranslation?.confidence}
        processingTime={lastTranslation?.processingTime}
        lastSaved={lastTranslation?.createdAt}
      />

      <KeyboardShortcutsModal
        open={showShortcuts}
        onOpenChange={setShowShortcuts}
      />
    </main>
  );
}
