import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Disable Monaco Editor workers to avoid errors in this environment
(self as any).MonacoEnvironment = {
  getWorker: function () {
    return {
      postMessage: () => {},
      terminate: () => {},
      addEventListener: () => {},
      removeEventListener: () => {}
    };
  }
};

createRoot(document.getElementById("root")!).render(<App />);
