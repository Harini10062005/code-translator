import { useQuery, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { Moon, Sun, User, ChevronDown } from "lucide-react";
import { Workspace } from "@shared/schema";
import { ThemeProvider, useTheme } from "@/components/ThemeProvider";
import { Toaster } from "@/components/ui/toaster";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sidebar } from "@/components/Sidebar";
import { TranslationPage } from "@/pages/TranslationPage";
import { KeyboardShortcutsModal } from "@/components/KeyboardShortcutsModal";
import { QuickTipsSidebar } from "@/components/QuickTipsSidebar";
import { queryClient } from "@/lib/queryClient";

function AppContent() {
  const { theme, toggleTheme } = useTheme();
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [showQuickTips, setShowQuickTips] = useState(false);
  const [activeWorkspaceId, setActiveWorkspaceId] = useState("main-project");

  const { data: workspaces = [] } = useQuery<Workspace[]>({
    queryKey: ["/api/workspaces"],
  });

  const activeWorkspace = workspaces.find(w => w.id === activeWorkspaceId) || {
    id: "main-project",
    name: "Main Project",
    isActive: true,
    createdAt: new Date(),
  };

  const handleCreateWorkspace = () => {
    // TODO: Implement workspace creation
    console.log("Create workspace");
  };

  const handleImportFile = () => {
    // TODO: Implement file import
    console.log("Import file");
  };

  const handleExportCode = () => {
    // TODO: Implement code export
    console.log("Export code");
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Enhanced Top Navigation */}
      <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/50 dark:border-slate-700/50 px-6 py-4 flex items-center justify-between shadow-sm animate-fade-in">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 via-purple-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg animate-gradient">
                <svg className="w-5 h-5 text-white animate-bounce-subtle" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14.6 16.6l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4zm-5.2 0L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4z"/>
                </svg>
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full animate-pulse-soft border-2 border-white dark:border-slate-900"></div>
            </div>
            <div>
              <h1 className="text-2xl font-bold gradient-text">
                CodeTranslate
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 -mt-1">
                AI-Powered Code Translation
              </p>
            </div>
          </div>
          <div className="hidden lg:flex items-center space-x-3 px-4 py-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-full border border-emerald-200 dark:border-emerald-800">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse-soft"></div>
            <span className="text-sm font-medium text-emerald-700 dark:text-emerald-300">
              Translation Engine Online
            </span>
            <div className="px-2 py-1 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 rounded-full text-xs font-medium">
              GPT-4
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="p-3 rounded-xl bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all duration-300 hover:scale-105"
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5 text-yellow-400" />
            ) : (
              <Moon className="h-5 w-5 text-slate-600" />
            )}
          </Button>

          <div className="flex items-center space-x-3 px-3 py-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/50 dark:border-slate-700/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-300 cursor-pointer">
            <Avatar className="w-9 h-9 ring-2 ring-blue-500/30 ring-offset-2 ring-offset-white dark:ring-offset-slate-900">
              <AvatarImage src="https://github.com/shadcn.png" alt="User" />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                <User className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                John Developer
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Pro Plan
              </p>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 transition-transform duration-200 hover:rotate-180" />
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          workspaces={workspaces}
          activeWorkspace={activeWorkspace}
          onCreateWorkspace={handleCreateWorkspace}
          onShowShortcuts={() => setShowShortcuts(true)}
          onShowQuickTips={() => setShowQuickTips(true)}
          onImportFile={handleImportFile}
          onExportCode={handleExportCode}
        />

        <TranslationPage activeWorkspaceId={activeWorkspaceId} />
      </div>

      <QuickTipsSidebar
        isOpen={showQuickTips}
        onToggle={() => setShowQuickTips(!showQuickTips)}
      />

      <KeyboardShortcutsModal
        open={showShortcuts}
        onOpenChange={setShowShortcuts}
      />

      <Toaster />
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <AppContent />
      </ThemeProvider>
    </QueryClientProvider>
  );
}
