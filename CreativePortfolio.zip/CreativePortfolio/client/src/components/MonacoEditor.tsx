import { useEffect, useRef } from "react";
import * as monaco from "monaco-editor";
import { Language } from "@shared/schema";

interface MonacoEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: Language;
  readOnly?: boolean;
  placeholder?: string;
  className?: string;
}

export function MonacoEditor({
  value,
  onChange,
  language,
  readOnly = false,
  placeholder,
  className = "",
}: MonacoEditorProps) {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor>();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Configure Monaco Editor theme
    monaco.editor.defineTheme("custom-dark", {
      base: "vs-dark",
      inherit: true,
      rules: [
        { token: "comment", foreground: "6B7280" },
        { token: "keyword", foreground: "A855F7" },
        { token: "string", foreground: "EF4444" },
        { token: "number", foreground: "10B981" },
        { token: "identifier", foreground: "60A5FA" },
      ],
      colors: {
        "editor.background": "#0F172A",
        "editor.foreground": "#F1F5F9",
        "editor.lineHighlightBackground": "#1E293B",
        "editor.selectionBackground": "#334155",
        "editorLineNumber.foreground": "#64748B",
        "editorLineNumber.activeForeground": "#CBD5E1",
      },
    });

    monaco.editor.defineTheme("custom-light", {
      base: "vs",
      inherit: true,
      rules: [
        { token: "comment", foreground: "6B7280" },
        { token: "keyword", foreground: "7C3AED" },
        { token: "string", foreground: "DC2626" },
        { token: "number", foreground: "059669" },
        { token: "identifier", foreground: "2563EB" },
      ],
      colors: {
        "editor.background": "#FFFFFF",
        "editor.foreground": "#1E293B",
        "editor.lineHighlightBackground": "#F8FAFC",
        "editor.selectionBackground": "#E2E8F0",
        "editorLineNumber.foreground": "#94A3B8",
        "editorLineNumber.activeForeground": "#475569",
      },
    });

    const editor = monaco.editor.create(containerRef.current, {
      value: value || placeholder || "",
      language: language.monacoLanguage,
      theme: document.documentElement.classList.contains("dark") ? "custom-dark" : "custom-light",
      readOnly,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      wordWrap: "on",
      lineNumbers: "on",
      renderLineHighlight: "line",
      selectOnLineNumbers: true,
      automaticLayout: true,
      fontFamily: "JetBrains Mono, monospace",
      fontSize: 14,
      lineHeight: 20,
      folding: true,
      foldingStrategy: "indentation",
      showFoldingControls: "always",
    });

    editorRef.current = editor;

    // Listen for content changes
    const disposable = editor.onDidChangeModelContent(() => {
      const newValue = editor.getValue();
      onChange(newValue);
    });

    // Listen for theme changes
    const themeObserver = new MutationObserver(() => {
      const isDark = document.documentElement.classList.contains("dark");
      monaco.editor.setTheme(isDark ? "custom-dark" : "custom-light");
    });

    themeObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => {
      disposable.dispose();
      themeObserver.disconnect();
      editor.dispose();
    };
  }, []);

  useEffect(() => {
    if (editorRef.current) {
      const currentValue = editorRef.current.getValue();
      if (currentValue !== value) {
        editorRef.current.setValue(value || placeholder || "");
      }
    }
  }, [value, placeholder]);

  useEffect(() => {
    if (editorRef.current) {
      monaco.editor.setModelLanguage(
        editorRef.current.getModel()!,
        language.monacoLanguage
      );
    }
  }, [language]);

  return (
    <div
      ref={containerRef}
      className={`h-full w-full ${className}`}
    />
  );
}
