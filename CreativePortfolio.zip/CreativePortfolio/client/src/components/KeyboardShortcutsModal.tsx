import { X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface KeyboardShortcutsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const shortcuts = [
  { action: "Translate Code", shortcut: "Ctrl + Enter" },
  { action: "Format Code", shortcut: "Ctrl + Shift + F" },
  { action: "Clear Editors", shortcut: "Ctrl + Shift + X" },
  { action: "Copy Result", shortcut: "Ctrl + Shift + C" },
  { action: "Toggle Theme", shortcut: "Ctrl + Shift + T" },
  { action: "Show Shortcuts", shortcut: "?" },
  { action: "Close Modal", shortcut: "Escape" },
];

export function KeyboardShortcutsModal({
  open,
  onOpenChange,
}: KeyboardShortcutsModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Keyboard Shortcuts
            <button
              onClick={() => onOpenChange(false)}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="h-4 w-4" />
            </button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          {shortcuts.map((item) => (
            <div key={item.action} className="flex items-center justify-between">
              <span className="text-sm text-slate-600 dark:text-slate-400">
                {item.action}
              </span>
              <kbd className="px-2 py-1 text-xs bg-slate-100 dark:bg-slate-700 rounded border font-mono">
                {item.shortcut}
              </kbd>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
