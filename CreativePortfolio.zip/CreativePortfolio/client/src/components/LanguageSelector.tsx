import { useState } from "react";
import { ChevronDown, Search } from "lucide-react";
import { Language } from "@shared/schema";
import { supportedLanguages } from "@/lib/languages";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface LanguageSelectorProps {
  value: Language;
  onValueChange: (language: Language) => void;
  label: string;
}

export function LanguageSelector({ value, onValueChange, label }: LanguageSelectorProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filteredLanguages = supportedLanguages.filter(lang =>
    lang.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="relative">
      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
        {label}
      </label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="min-w-[140px] justify-between bg-slate-50 dark:bg-slate-700 border-slate-200 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-600"
          >
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 rounded bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">
                  {value.short.substring(0, 2)}
                </span>
              </div>
              <span className="font-medium">{value.name}</span>
            </div>
            <ChevronDown className="ml-2 h-4 w-4 shrink-0 text-slate-400" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0" align="start">
          <div className="p-2">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search languages..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
          <div className="max-h-48 overflow-y-auto">
            {filteredLanguages.length === 0 ? (
              <div className="p-2 text-sm text-slate-500 text-center">
                No languages found
              </div>
            ) : (
              filteredLanguages.map((language) => (
                <button
                  key={language.id}
                  onClick={() => {
                    onValueChange(language);
                    setOpen(false);
                    setSearch("");
                  }}
                  className="w-full flex items-center space-x-3 px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-600 text-left transition-colors"
                >
                  <div className="w-4 h-4 rounded bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                    <span className="text-[8px] font-bold text-white">
                      {language.short.substring(0, 2)}
                    </span>
                  </div>
                  <span className="text-sm">{language.name}</span>
                </button>
              ))
            )}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
