import { useEffect, useRef } from "react";
import { Language } from "@shared/schema";

interface SimpleCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: Language;
  readOnly?: boolean;
  placeholder?: string;
  className?: string;
}

export function SimpleCodeEditor({
  value,
  onChange,
  language,
  readOnly = false,
  placeholder,
  className = "",
}: SimpleCodeEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [value]);

  return (
    <div className={`h-full w-full relative ${className}`}>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        readOnly={readOnly}
        placeholder={placeholder}
        className="w-full h-full min-h-[400px] p-4 bg-transparent border-none outline-none resize-none font-mono text-sm leading-6 text-slate-800 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-500"
        style={{
          fontFamily: 'JetBrains Mono, monospace',
          lineHeight: '1.6',
        }}
      />
      
      {/* Language indicator */}
      <div className="absolute top-4 right-4 px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded text-xs font-medium text-slate-600 dark:text-slate-400 opacity-50">
        {language.name}
      </div>
    </div>
  );
}