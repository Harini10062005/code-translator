import { Plus, Clock, FolderInput, Download, Keyboard, ArrowRight, Circle, Bot, Lightbulb } from "lucide-react";
import { Workspace } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useRecentTranslations } from "@/hooks/useTranslation";
import { formatDistanceToNow } from "date-fns";

interface SidebarProps {
  workspaces: Workspace[];
  activeWorkspace: Workspace;
  onCreateWorkspace: () => void;
  onShowShortcuts: () => void;
  onShowQuickTips: () => void;
  onImportFile: () => void;
  onExportCode: () => void;
}

export function Sidebar({
  workspaces,
  activeWorkspace,
  onCreateWorkspace,
  onShowShortcuts,
  onShowQuickTips,
  onImportFile,
  onExportCode,
}: SidebarProps) {
  const { data: recentTranslations = [], isLoading } = useRecentTranslations();

  return (
    <aside className="w-72 bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur-sm border-r border-slate-200/50 dark:border-slate-700/50 flex flex-col animate-slide-in-left">
      {/* Workspace Section */}
      <div className="p-6 border-b border-slate-200/50 dark:border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse-soft"></div>
            <h2 className="text-sm font-bold text-slate-800 dark:text-slate-200 tracking-wide uppercase">
              Workspaces
            </h2>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={onCreateWorkspace}
            className="h-8 w-8 p-0 rounded-lg bg-blue-50 dark:bg-blue-900/30 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-all duration-200 hover:scale-105"
          >
            <Plus className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </Button>
        </div>

        <div className="space-y-2">
          {workspaces.map((workspace, index) => (
            <div
              key={workspace.id}
              className={`flex items-center space-x-3 p-3 rounded-xl transition-all duration-300 animate-fade-in group cursor-pointer ${
                workspace.id === activeWorkspace.id
                  ? "bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 border border-blue-200 dark:border-blue-700 shadow-sm"
                  : "hover:bg-white/80 dark:hover:bg-slate-800/50 hover:shadow-sm border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative">
                <Circle
                  className={`w-3 h-3 transition-all duration-200 ${
                    workspace.id === activeWorkspace.id
                      ? "fill-blue-500 text-blue-500 animate-pulse-soft"
                      : "fill-slate-300 dark:fill-slate-600 text-slate-300 dark:text-slate-600 group-hover:fill-blue-400 group-hover:text-blue-400"
                  }`}
                />
                {workspace.id === activeWorkspace.id && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400 rounded-full animate-pulse-soft"></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <span
                  className={`text-sm font-semibold block truncate transition-colors duration-200 ${
                    workspace.id === activeWorkspace.id
                      ? "text-blue-700 dark:text-blue-300"
                      : "text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-slate-100"
                  }`}
                >
                  {workspace.name}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  {workspace.id === activeWorkspace.id ? "Active" : "Workspace"}
                </span>
              </div>
              {workspace.id === activeWorkspace.id && (
                <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse-soft"></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Recent Translations */}
      <div className="p-6 border-b border-slate-200/50 dark:border-slate-700/50">
        <div className="flex items-center space-x-2 mb-4">
          <Clock className="w-4 h-4 text-slate-500 dark:text-slate-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 tracking-wide uppercase">
            Recent Translations
          </h3>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="p-3 rounded-xl bg-white/50 dark:bg-slate-800/30 animate-pulse">
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-lg mb-2" />
                <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-lg w-3/4" />
              </div>
            ))}
          </div>
        ) : recentTranslations.length > 0 ? (
          <div className="space-y-3">
            {recentTranslations.slice(0, 5).map((translation, index) => (
              <div
                key={translation.id}
                className="p-3 rounded-xl bg-white/60 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800/60 cursor-pointer transition-all duration-300 group border border-transparent hover:border-slate-200 dark:hover:border-slate-700 hover:shadow-sm animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className="flex items-center space-x-1">
                      <span className="text-xs px-2 py-1 bg-gradient-to-r from-orange-100 to-yellow-100 dark:from-orange-900/30 dark:to-yellow-900/30 text-orange-700 dark:text-orange-300 rounded-lg font-medium">
                        {translation.sourceLanguage.short}
                      </span>
                      <ArrowRight className="w-3 h-3 text-slate-400 group-hover:text-blue-500 transition-colors" />
                      <span className="text-xs px-2 py-1 bg-gradient-to-r from-emerald-100 to-green-100 dark:from-emerald-900/30 dark:to-green-900/30 text-emerald-700 dark:text-emerald-300 rounded-lg font-medium">
                        {translation.targetLanguage.short}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300 font-medium">
                    {formatDistanceToNow(translation.createdAt, { addSuffix: true }).replace('about ', '')}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 font-mono bg-slate-50 dark:bg-slate-900/50 px-2 py-1 rounded-lg truncate group-hover:bg-slate-100 dark:group-hover:bg-slate-900 transition-colors">
                  {translation.sourceCode.split('\n')[0].slice(0, 35)}...
                </p>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center space-x-1">
                    <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></div>
                    <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      {translation.confidence}% confidence
                    </span>
                  </div>
                  <span className="text-xs text-slate-400">
                    {(translation.processingTime / 1000).toFixed(1)}s
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-4 p-6 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800/30 dark:to-slate-900/50 rounded-xl border border-slate-200/50 dark:border-slate-700/50">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 rounded-xl flex items-center justify-center mb-3">
                <Clock className="w-6 h-6 text-blue-500 dark:text-blue-400" />
              </div>
              <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">
                No translations yet
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Start translating code to see your history here
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Enhanced Actions */}
      <div className="p-6 space-y-3">
        <Button
          variant="ghost"
          className="w-full justify-start p-3 rounded-xl bg-white/60 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800/60 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all duration-300 group"
          onClick={onImportFile}
        >
          <div className="w-8 h-8 bg-blue-50 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-3 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/50 transition-colors">
            <FolderInput className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          </div>
          <span className="font-medium">Import File</span>
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start p-3 rounded-xl bg-white/60 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800/60 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all duration-300 group"
          onClick={onExportCode}
        >
          <div className="w-8 h-8 bg-emerald-50 dark:bg-emerald-900/30 rounded-lg flex items-center justify-center mr-3 group-hover:bg-emerald-100 dark:group-hover:bg-emerald-900/50 transition-colors">
            <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <span className="font-medium">Export Code</span>
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start p-3 rounded-xl bg-white/60 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800/60 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all duration-300 group"
          onClick={onShowQuickTips}
        >
          <div className="w-8 h-8 bg-yellow-50 dark:bg-yellow-900/30 rounded-lg flex items-center justify-center mr-3 group-hover:bg-yellow-100 dark:group-hover:bg-yellow-900/50 transition-colors">
            <Lightbulb className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
          </div>
          <span className="font-medium">Quick Tips</span>
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start p-3 rounded-xl bg-white/60 dark:bg-slate-800/30 hover:bg-white dark:hover:bg-slate-800/60 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all duration-300 group"
          onClick={onShowShortcuts}
        >
          <div className="w-8 h-8 bg-purple-50 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mr-3 group-hover:bg-purple-100 dark:group-hover:bg-purple-900/50 transition-colors">
            <Keyboard className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </div>
          <span className="font-medium">Shortcuts</span>
        </Button>
      </div>

      {/* Enhanced Footer */}
      <div className="mt-auto p-6 border-t border-slate-200/50 dark:border-slate-700/50">
        <div className="bg-gradient-to-r from-blue-50 via-purple-50 to-blue-50 dark:from-blue-900/20 dark:via-purple-900/20 dark:to-blue-900/20 p-4 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  Powered by AI
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  GPT-4 Translation Engine
                </p>
              </div>
            </div>
            <div className="px-3 py-1.5 bg-gradient-to-r from-emerald-400 to-emerald-500 text-white rounded-lg text-xs font-bold shadow-sm">
              PRO
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
