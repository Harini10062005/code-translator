import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Lightbulb, 
  Code, 
  Shield, 
  Zap, 
  BookOpen, 
  Target, 
  ChevronRight,
  ChevronDown,
  Star
} from "lucide-react";
import { Language } from "@shared/schema";

interface QuickTip {
  id: string;
  title: string;
  description: string;
  category: "general" | "security" | "performance" | "readability" | "testing";
  languages?: string[];
  priority: "high" | "medium" | "low";
  example?: string;
}

interface QuickTipsSidebarProps {
  currentLanguage?: Language;
  isOpen: boolean;
  onToggle: () => void;
}

const codingTips: QuickTip[] = [
  {
    id: "1",
    title: "Use Meaningful Variable Names",
    description: "Choose descriptive names that clearly indicate the variable's purpose and content.",
    category: "readability",
    priority: "high",
    example: "// Good: userAge, totalPrice\n// Bad: x, temp, data"
  },
  {
    id: "2",
    title: "Keep Functions Small",
    description: "Functions should do one thing well. Aim for 20-30 lines maximum.",
    category: "readability",
    priority: "high",
    example: "// Split complex functions into smaller, focused ones"
  },
  {
    id: "3",
    title: "Validate Input Data",
    description: "Always validate and sanitize user input to prevent security vulnerabilities.",
    category: "security",
    priority: "high",
    languages: ["javascript", "python", "java", "csharp"]
  },
  {
    id: "4",
    title: "Use Consistent Indentation",
    description: "Maintain consistent code formatting throughout your project.",
    category: "readability",
    priority: "medium",
    example: "// Use 2 or 4 spaces consistently"
  },
  {
    id: "5",
    title: "Avoid Deep Nesting",
    description: "Limit nesting levels to improve code readability. Use early returns when possible.",
    category: "readability",
    priority: "medium",
    example: "// Use guard clauses instead of nested if statements"
  },
  {
    id: "6",
    title: "Handle Errors Gracefully",
    description: "Implement proper error handling to make your application more robust.",
    category: "general",
    priority: "high",
    languages: ["javascript", "python", "java", "csharp", "go"]
  },
  {
    id: "7",
    title: "Optimize Loops",
    description: "Avoid unnecessary computations inside loops. Cache results when possible.",
    category: "performance",
    priority: "medium",
    example: "// Calculate once outside the loop, not on every iteration"
  },
  {
    id: "8",
    title: "Use Comments Wisely",
    description: "Write comments that explain 'why', not 'what'. The code should be self-documenting.",
    category: "readability",
    priority: "medium",
    example: "// Good: Explains business logic\n// Bad: Describes obvious code"
  },
  {
    id: "9",
    title: "Follow DRY Principle",
    description: "Don't Repeat Yourself. Extract common functionality into reusable functions.",
    category: "general",
    priority: "high"
  },
  {
    id: "10",
    title: "Use Version Control",
    description: "Commit code frequently with meaningful commit messages.",
    category: "general",
    priority: "high",
    example: "git commit -m 'Add user authentication validation'"
  }
];

const categoryIcons = {
  general: Code,
  security: Shield,
  performance: Zap,
  readability: BookOpen,
  testing: Target
};

const categoryColors = {
  general: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300",
  security: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300",
  performance: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300",
  readability: "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300",
  testing: "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300"
};

const priorityColors = {
  high: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300",
  low: "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
};

export function QuickTipsSidebar({ currentLanguage, isOpen, onToggle }: QuickTipsSidebarProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [expandedTip, setExpandedTip] = useState<string | null>(null);

  const categories = ["all", "general", "security", "performance", "readability", "testing"];

  const filteredTips = codingTips.filter(tip => {
    if (selectedCategory === "all") return true;
    if (selectedCategory !== tip.category) return false;
    if (currentLanguage && tip.languages && !tip.languages.includes(currentLanguage.id)) {
      return false;
    }
    return true;
  });

  const highPriorityTips = filteredTips.filter(tip => tip.priority === "high");

  if (!isOpen) {
    return (
      <Button
        onClick={onToggle}
        size="sm"
        variant="outline"
        className="fixed right-4 top-20 z-50 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm border border-slate-200/50 dark:border-slate-700/50 shadow-lg hover:shadow-xl transition-all duration-200"
      >
        <Lightbulb className="w-4 h-4 mr-2" />
        Quick Tips
      </Button>
    );
  }

  return (
    <div className="fixed right-0 top-0 h-full w-80 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-l border-slate-200/50 dark:border-slate-700/50 shadow-2xl z-40 animate-fade-in">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b border-slate-200/50 dark:border-slate-700/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <Lightbulb className="w-4 h-4 text-white" />
              </div>
              <h2 className="text-lg font-bold text-slate-800 dark:text-slate-200">
                Quick Tips
              </h2>
            </div>
            <Button onClick={onToggle} size="sm" variant="ghost">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          
          {currentLanguage && (
            <div className="mt-3">
              <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300">
                {currentLanguage.name} specific tips
              </Badge>
            </div>
          )}
        </div>

        {/* Category Filter */}
        <div className="p-4 border-b border-slate-200/50 dark:border-slate-700/50">
          <div className="grid grid-cols-2 gap-2">
            {categories.map((category) => {
              const Icon = category === "all" ? Star : categoryIcons[category as keyof typeof categoryIcons];
              return (
                <Button
                  key={category}
                  size="sm"
                  variant={selectedCategory === category ? "default" : "ghost"}
                  onClick={() => setSelectedCategory(category)}
                  className="justify-start text-xs"
                >
                  {Icon && <Icon className="w-3 h-3 mr-1" />}
                  {category === "all" ? "All" : category.charAt(0).toUpperCase() + category.slice(1)}
                </Button>
              );
            })}
          </div>
        </div>

        {/* High Priority Tips */}
        {selectedCategory === "all" && highPriorityTips.length > 0 && (
          <div className="p-4 border-b border-slate-200/50 dark:border-slate-700/50">
            <h3 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center">
              <Star className="w-4 h-4 mr-1 text-yellow-500" />
              High Priority
            </h3>
            <div className="space-y-2">
              {highPriorityTips.slice(0, 3).map((tip) => (
                <div
                  key={tip.id}
                  className="p-2 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/10 dark:to-orange-900/10 rounded-lg border border-yellow-200/50 dark:border-yellow-800/50"
                >
                  <div className="text-xs font-medium text-slate-800 dark:text-slate-200">
                    {tip.title}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tips List */}
        <ScrollArea className="flex-1">
          <div className="p-4 space-y-3">
            {filteredTips.map((tip) => {
              const CategoryIcon = categoryIcons[tip.category];
              const isExpanded = expandedTip === tip.id;

              return (
                <Card key={tip.id} className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-slate-200/50 dark:border-slate-700/50 hover:shadow-md transition-all duration-200">
                  <CardHeader 
                    className="p-3 cursor-pointer"
                    onClick={() => setExpandedTip(isExpanded ? null : tip.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <CategoryIcon className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                          <CardTitle className="text-sm font-medium text-slate-800 dark:text-slate-200">
                            {tip.title}
                          </CardTitle>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={`text-xs ${categoryColors[tip.category]}`}>
                            {tip.category}
                          </Badge>
                          <Badge className={`text-xs ${priorityColors[tip.priority]}`}>
                            {tip.priority}
                          </Badge>
                        </div>
                      </div>
                      {isExpanded ? (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </CardHeader>
                  
                  {isExpanded && (
                    <CardContent className="p-3 pt-0">
                      <Separator className="mb-3" />
                      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                        {tip.description}
                      </p>
                      
                      {tip.example && (
                        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-3 border border-slate-200/50 dark:border-slate-700/50">
                          <div className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
                            Example:
                          </div>
                          <pre className="text-xs text-slate-600 dark:text-slate-400 whitespace-pre-wrap font-mono">
                            {tip.example}
                          </pre>
                        </div>
                      )}
                      
                      {tip.languages && (
                        <div className="mt-3 flex flex-wrap gap-1">
                          {tip.languages.map((lang) => (
                            <Badge key={lang} variant="outline" className="text-xs">
                              {lang}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>
              );
            })}
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200/50 dark:border-slate-700/50">
          <div className="text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {filteredTips.length} tips available
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}