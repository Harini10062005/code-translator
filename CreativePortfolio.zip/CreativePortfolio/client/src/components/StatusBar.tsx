import { Circle, TrendingUp } from "lucide-react";

interface StatusBarProps {
  sourceStats: { lines: number; chars: number };
  translatedStats: { lines: number; chars: number };
  confidence?: number;
  processingTime?: number;
  lastSaved?: Date;
}

export function StatusBar({
  sourceStats,
  translatedStats,
  confidence,
  processingTime,
  lastSaved,
}: StatusBarProps) {
  return (
    <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm border-t border-slate-200/50 dark:border-slate-700/50 px-6 py-3 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6 text-sm">
          <div className="flex items-center space-x-2 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-900/30 rounded-lg border border-emerald-200 dark:border-emerald-800">
            <Circle className="w-2 h-2 fill-emerald-500 text-emerald-500 animate-pulse-soft" />
            <span className="font-medium text-emerald-700 dark:text-emerald-300">
              Engine Online
            </span>
          </div>
          
          <div className="flex items-center space-x-4 text-slate-600 dark:text-slate-400">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-500 uppercase tracking-wide">Source:</span>
              <span className="px-2 py-1 bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 rounded-md text-xs font-medium">
                {sourceStats.lines} lines
              </span>
              <span className="px-2 py-1 bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 rounded-md text-xs font-medium">
                {sourceStats.chars} chars
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-500 uppercase tracking-wide">Translated:</span>
              <span className="px-2 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-md text-xs font-medium">
                {translatedStats.lines} lines
              </span>
              <span className="px-2 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-md text-xs font-medium">
                {translatedStats.chars} chars
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {confidence && (
            <div className="flex items-center space-x-2 px-3 py-1.5 bg-blue-50 dark:bg-blue-900/30 rounded-lg border border-blue-200 dark:border-blue-800">
              <TrendingUp className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                Confidence: 
              </span>
              <span className="text-sm font-bold text-blue-600 dark:text-blue-400">
                {confidence}%
              </span>
            </div>
          )}
          
          {processingTime && (
            <div className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
              <span className="font-medium">Processing:</span>
              <span className="px-2 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-md font-medium">
                {(processingTime / 1000).toFixed(1)}s
              </span>
            </div>
          )}
          
          {lastSaved && (
            <div className="text-sm text-slate-500 dark:text-slate-400 font-medium">
              Last saved: {new Date(lastSaved).toLocaleTimeString()}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
