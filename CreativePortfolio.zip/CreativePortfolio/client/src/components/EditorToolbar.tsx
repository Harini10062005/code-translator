import { ArrowLeftRight, Indent, Eraser, Wand2 } from "lucide-react";
import { Language } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { LanguageSelector } from "./LanguageSelector";

interface EditorToolbarProps {
  sourceLanguage: Language;
  targetLanguage: Language;
  onSourceLanguageChange: (language: Language) => void;
  onTargetLanguageChange: (language: Language) => void;
  onSwapLanguages: () => void;
  onFormat: () => void;
  onClear: () => void;
  onTranslate: () => void;
  isTranslating: boolean;
}

export function EditorToolbar({
  sourceLanguage,
  targetLanguage,
  onSourceLanguageChange,
  onTargetLanguageChange,
  onSwapLanguages,
  onFormat,
  onClear,
  onTranslate,
  isTranslating,
}: EditorToolbarProps) {
  return (
    <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm border-b border-slate-200/50 dark:border-slate-700/50 p-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          {/* Enhanced Language Selectors */}
          <div className="flex items-center space-x-4">
            <div className="animate-slide-up">
              <LanguageSelector
                value={sourceLanguage}
                onValueChange={onSourceLanguageChange}
                label="Source Language"
              />
            </div>

            {/* Enhanced Translation Arrow */}
            <div className="flex flex-col items-center justify-center pt-6">
              <Button
                size="sm"
                variant="outline"
                onClick={onSwapLanguages}
                className="p-3 rounded-full bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 hover:from-blue-100 hover:to-purple-100 dark:hover:from-blue-900/50 dark:hover:to-purple-900/50 border-blue-200 dark:border-blue-700 transition-all duration-300 hover:scale-110 shadow-sm hover:shadow-md"
              >
                <ArrowLeftRight className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </Button>
            </div>

            <div className="animate-slide-up" style={{ animationDelay: "0.1s" }}>
              <LanguageSelector
                value={targetLanguage}
                onValueChange={onTargetLanguageChange}
                label="Target Language"
              />
            </div>
          </div>
        </div>

        {/* Enhanced Action Buttons */}
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            onClick={onFormat}
            className="px-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 transition-all duration-300 hover:scale-105 shadow-sm"
          >
            <Indent className="w-4 h-4 mr-2 text-slate-600 dark:text-slate-400" />
            <span className="font-medium">Format</span>
          </Button>

          <Button 
            variant="ghost" 
            onClick={onClear}
            className="px-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-red-50 dark:hover:bg-red-900/20 border border-slate-200/50 dark:border-slate-700/50 hover:border-red-200 dark:hover:border-red-800 transition-all duration-300 hover:scale-105 shadow-sm group"
          >
            <Eraser className="w-4 h-4 mr-2 text-slate-600 dark:text-slate-400 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors" />
            <span className="font-medium group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">Clear</span>
          </Button>

          <Button
            onClick={onTranslate}
            disabled={isTranslating}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none font-semibold"
          >
            {isTranslating ? (
              <>
                <div className="w-5 h-5 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Translating...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5 mr-2" />
                <span>Translate Code</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
