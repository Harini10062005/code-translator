import { useEffect } from "react";

interface KeyboardShortcuts {
  onTranslate?: () => void;
  onFormat?: () => void;
  onClear?: () => void;
  onCopy?: () => void;
  onToggleTheme?: () => void;
}

export function useKeyboardShortcuts({
  onTranslate,
  onFormat,
  onClear,
  onCopy,
  onToggleTheme,
}: KeyboardShortcuts) {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Ctrl + Enter for translate
      if (event.ctrlKey && event.key === "Enter") {
        event.preventDefault();
        onTranslate?.();
      }

      // Ctrl + Shift + F for format
      if (event.ctrlKey && event.shiftKey && event.key === "F") {
        event.preventDefault();
        onFormat?.();
      }

      // Ctrl + Shift + X for clear
      if (event.ctrlKey && event.shiftKey && event.key === "X") {
        event.preventDefault();
        onClear?.();
      }

      // Ctrl + Shift + C for copy
      if (event.ctrlKey && event.shiftKey && event.key === "C") {
        event.preventDefault();
        onCopy?.();
      }

      // Ctrl + Shift + T for theme toggle
      if (event.ctrlKey && event.shiftKey && event.key === "T") {
        event.preventDefault();
        onToggleTheme?.();
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onTranslate, onFormat, onClear, onCopy, onToggleTheme]);
}
