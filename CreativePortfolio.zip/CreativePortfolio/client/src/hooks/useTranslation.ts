import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Translation, TranslateCodeRequest } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useTranslation() {
  const queryClient = useQueryClient();

  const translateCode = useMutation({
    mutationFn: (data: TranslateCodeRequest) =>
      apiRequest<Translation>("/api/translate", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      // Invalidate and refetch translations
      queryClient.invalidateQueries({ queryKey: ["/api/translations"] });
    },
  });

  return {
    translateCode,
    isTranslating: translateCode.isPending,
  };
}

export function useRecentTranslations() {
  return useQuery<Translation[]>({
    queryKey: ["/api/translations", "recent"],
    queryFn: () => apiRequest("/api/translations/recent"),
  });
}

export function useWorkspaceTranslations(workspaceId: string) {
  return useQuery<Translation[]>({
    queryKey: ["/api/translations", "workspace", workspaceId],
    queryFn: () => apiRequest(`/api/translations/workspace/${workspaceId}`),
    enabled: !!workspaceId,
  });
}
