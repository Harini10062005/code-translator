import { Language } from "@shared/schema";

export async function formatCode(code: string, language: Language): Promise<string> {
  try {
    const response = await fetch("/api/format", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ code, language }),
    });

    if (!response.ok) {
      throw new Error("Formatting failed");
    }

    const result = await response.json();
    return result.formattedCode;
  } catch (error) {
    console.error("Code formatting error:", error);
    return code; // Return original code if formatting fails
  }
}

export function getCodeStats(code: string) {
  const lines = code.split('\n').length;
  const chars = code.length;
  const nonEmptyLines = code.split('\n').filter(line => line.trim().length > 0).length;
  
  return {
    lines,
    chars,
    nonEmptyLines,
  };
}
