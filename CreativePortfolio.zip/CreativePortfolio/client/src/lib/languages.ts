import { Language } from "@shared/schema";

export const supportedLanguages: Language[] = [
  {
    id: "python",
    name: "Python",
    short: "PY",
    fileExtension: ".py",
    monacoLanguage: "python",
  },
  {
    id: "javascript",
    name: "JavaScript",
    short: "JS",
    fileExtension: ".js",
    monacoLanguage: "javascript",
  },
  {
    id: "typescript",
    name: "TypeScript",
    short: "TS",
    fileExtension: ".ts",
    monacoLanguage: "typescript",
  },
  {
    id: "java",
    name: "Java",
    short: "JAVA",
    fileExtension: ".java",
    monacoLanguage: "java",
  },
  {
    id: "cpp",
    name: "C++",
    short: "C++",
    fileExtension: ".cpp",
    monacoLanguage: "cpp",
  },
  {
    id: "csharp",
    name: "C#",
    short: "C#",
    fileExtension: ".cs",
    monacoLanguage: "csharp",
  },
  {
    id: "go",
    name: "Go",
    short: "GO",
    fileExtension: ".go",
    monacoLanguage: "go",
  },
  {
    id: "rust",
    name: "Rust",
    short: "RS",
    fileExtension: ".rs",
    monacoLanguage: "rust",
  },
  {
    id: "php",
    name: "PHP",
    short: "PHP",
    fileExtension: ".php",
    monacoLanguage: "php",
  },
  {
    id: "ruby",
    name: "Ruby",
    short: "RB",
    fileExtension: ".rb",
    monacoLanguage: "ruby",
  },
  {
    id: "swift",
    name: "Swift",
    short: "SWIFT",
    fileExtension: ".swift",
    monacoLanguage: "swift",
  },
  {
    id: "kotlin",
    name: "Kotlin",
    short: "KT",
    fileExtension: ".kt",
    monacoLanguage: "kotlin",
  },
];

export function getLanguageById(id: string): Language | undefined {
  return supportedLanguages.find(lang => lang.id === id);
}

export function getLanguageByExtension(extension: string): Language | undefined {
  return supportedLanguages.find(lang => lang.fileExtension === extension);
}
